#!/bin/bash
cd /home/ebran/Developer/projects/data_score_factors
/home/ebran/Developer/projects/data_score_factors/venv/bin/streamlit run fraud_detection/app.py --server.port 8501 --server.headless true
